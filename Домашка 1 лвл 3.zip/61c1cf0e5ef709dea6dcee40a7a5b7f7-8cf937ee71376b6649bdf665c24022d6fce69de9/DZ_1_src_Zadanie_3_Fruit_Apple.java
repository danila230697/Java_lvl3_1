package Zadanie_3_Fruit;

public class Apple extends Fruit {

    public Apple() {
        super(5,6);
    }
}
