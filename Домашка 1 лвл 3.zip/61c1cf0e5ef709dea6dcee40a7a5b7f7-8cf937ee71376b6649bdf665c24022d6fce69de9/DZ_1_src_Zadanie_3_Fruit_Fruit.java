package Zadanie_3_Fruit;

public abstract class Fruit {
public double ves;
public double kol;
public  Fruit(double kol,double ves) {
      this.ves=ves;
      this.kol=kol;

    }


}
