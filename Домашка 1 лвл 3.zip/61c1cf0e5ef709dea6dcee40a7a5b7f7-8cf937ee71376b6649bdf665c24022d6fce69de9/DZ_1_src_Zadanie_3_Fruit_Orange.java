package Zadanie_3_Fruit;

public class Orange extends Fruit {
    public Orange() {
        super(7, 8);
    }
}
